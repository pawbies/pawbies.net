# Handoff: pawbies.net — Personal Homepage (Kawaii Zine)

## Overview
A personal homepage for **pawbies** (`pawbies.net`) styled as a kawaii scrapbook zine. Plum + magenta aesthetic, paper cards with washi tape and stickers, hand-drawn doodles, a cat-mascot cursor with paw trail, and an ambient floaty-doodle background. Single long-scroll page with a sticky nav and a tweak panel for theming.

## About the Design Files
The files in `source/` are **design references created in HTML** — a working prototype showing intended look and behavior, not production code to copy verbatim. The task is to **recreate this design in your target codebase's environment** (e.g. Astro / Next.js / Eleventy / SvelteKit / plain HTML+CSS), using whatever framework and styling system is most appropriate. If no environment exists yet, **Astro or Eleventy** are great fits for a personal homepage; React + Tailwind also works.

The HTML prototype uses inline JSX + Babel (loaded via CDN) for fast iteration. You should not ship that — port the components into your stack and load fonts properly.

## Fidelity
**High-fidelity.** Colors, typography, spacing, decorative details, animations, and copy are all final-as-of-handoff. Recreate pixel-close, then deviate as content/needs evolve.

## Screens / Views
One scrolling page. From top to bottom:

### Sticky Nav
- Position: sticky top, full width, 10px × 32px padding
- Background: `#1f1428cc` with 12px backdrop blur
- Border-bottom: `1px dashed var(--accent)55`
- Left: site title "pawbies.net" — display font, 22px, accent color (".net" in lilac)
- Right: anchor links (`about`, `blog`, `projects`, `gym`, `photos`, `guests`, `links`) — script font, 13px, white, on hover get an accent-tinted pill background

### Hero Card
- Tilted (-1°), `padding: 26px 32px`, sits inside a 1180px content max-width
- Two pieces of decorative tape on top (one each side, opposite rotations)
- Left: 120px circular avatar (placeholder with "pb" initials), ringed with paper + accent + drop-shadow, three doodle stickers attached (sparkle top-right, heart bottom-left, bow top)
- Right: greeting line ("hi hi !! welcome to" — script font, 22px, accent), big display name "pawbies.net" (display font, 80px, accent + lilac for `.net`), tagline ("✿ silly femboy gymbro ^^ ✿" — script font, 26px, ink), bio paragraph (14px, dark plum), pill-tags row with dashed accent border

### Three-Column Collage Grid
- 3 equal columns, 32px gap, `align-items: start`
- Middle column has a `marginTop: 18` to break the grid rhythm
- Each card has its own piece of tape, slight rotation (driven by `cardRotation` tweak), and optional sticker accent

**Column 1 (left)**
1. **say hi ♡** — links card. Three rows: GitHub (accent bg square + icon), Instagram (lilac), email (mint). Each row is its own pastel-tint background.
2. **photo booth** — strip of 3 photo placeholders on a black "film" card with paper backing per photo, gentle alternating rotation. Footer label in script font.
3. **my stack ★** — paper card with dashed accent border, list of `category: items` rows. Category labels in script font.

**Column 2 (middle)**
1. **blog ✎** — list of 5 posts. Each row: title (13.5px bold), tag (script font #tag) + date · read-time (mono 10.5px). Dashed dividers. "more posts →" footer link.
2. **now spinning ♪** — vinyl record (conic-gradient circle, 5s spin animation) + current track. Below: 3-track scrolling list in mono, with "♪" prefix and italic context note.
3. **gym log ⚡** — header w/ streak number ("47 days!!" script 30px) + split note. List of lifts (squat/bench/dl/ohp) with values in mono accent on the right.

**Column 3 (right)**
1. **guestbook** — 4 message blocks alternating pink/mint pastel backgrounds, slight ±0.6° rotation, script font 15px. Big "✎ sign it!!" gradient button at bottom (accent → pink) with hard offset shadow.
2. **projects ✿** — 4 projects. Mono `./name` in accent + star count, description, language indicator with bullet.
3. **reading rn 📖** — small card with a synthetic book-cover (gradient with kanji "フリーレン") + title/author/star rating in script font.

### Footer
Centered, `marginTop: 50`, script font 22px in pink. Two lines: "made with ♡ & protein by pb · 2026" + smaller mono "thanks for stopping by ✿".

### Cursor Mascot (overlay)
- Tiny SVG kitty drawn next to the cursor (offset +14, +6), pink head with white inner ears, dot eyes with white highlight, blush, mouth, whiskers
- Paw-print trail: every ~60px of cursor movement drops a paw SVG, alternating L/R offset (perpendicular to motion vector by ±12px), rotated to match motion
- Paws fade out over 1.4s (animation: scale up briefly, then fade)
- Trail capped at last 12 paws
- Toggleable via tweaks panel

### Tweaks Panel
- Bottom-right floating glass panel
- Sections: Color (accent picker, paper select), Decor (doodle density 0–30, card tilt 0–4°, tape style: washi/solid/dotted/striped), Type (display + script font radios), Mascot (on/off)
- Persists via the host tweak protocol — for production, swap to localStorage or remove entirely

## Interactions & Behavior
- **Smooth-scroll** to anchored sections from nav
- **Floating doodles**: ~12 doodles randomly placed across viewport, looping `floaty` keyframe (translateY ±6px, 3–7s cycle, staggered delay)
- **Sticker animations**: `wobble` (rotate -8↔8°, 4s), `twinkle` (scale + opacity, 2–2.5s)
- **Vinyl spin**: continuous 360° rotation, 5s linear infinite
- **Nav hover**: background color fades in (`.15s` transition)
- **Cursor mascot**: kitty follows cursor (no easing — direct), paws drop on movement and fade over 1.4s
- **Hover** on link rows in "say hi" card → already has a tinted bg; you can intensify it on hover

## State Management
Minimal. The only state in the prototype is the tweaks panel. For production:
- Site is mostly static — generate at build time
- Guestbook needs persistence (local-first JSON, or a tiny backend like a serverless function + KV)
- "Now playing" can pull from Last.fm / Spotify API at build or via edge function
- Gym log can read from a markdown file or JSON

## Design Tokens

### Colors
```
--plum-bg-0    #1f1428   (page bg)
--plum-bg-1    #1a0822   (deepest, nav scrim, film strip)
--plum-glow-1  #4e1e5a   (radial glow top-left)
--plum-glow-2  #3a2a48   (radial glow bottom-right)
--ink          #2a1535   (body text on paper)
--paper        #fff3f9   (default; cream tweak option)
                          alts: #fff7e8 vanilla, #e8fff5 mint,
                                #eaf3ff sky, #f4eaff lilac
--accent       #ff2fb3   (hot magenta — primary)
--pink         #ff94d4   (secondary pink)
--lilac        #d9a7ff
--mint         #7affd3
--amber        #ffce6b
```

### Typography
- **Display**: Shrikhand (default), with DynaPuff & Pacifico as alts. Used for big headings, card titles. Letter-spacing -1 to -2 on hero.
- **Script**: Caveat (default), with Reenie Beanie & Fredoka as alts. Used for taglines, accents, friendly labels.
- **Body / UI**: Fredoka 400/500/600/700.
- **Mono**: JetBrains Mono — dates, project names with `./`, lang indicators, timestamps.

### Spacing
- Page max-width: `1180px`
- Page padding: `32px 40px 60px`
- Grid gap: `32px` (column), `30px` (intra-column)
- Card padding: `16px` standard, `26px 32px` for hero
- Border-radius: cards `2px` (paper feel), pills `99px`, photo strip `0`, link squares `6px`

### Decorative
- Card shadow: `0 6px 20px #0006, 0 1px 0 #00000022`
- Tape: 18px tall, 50–90px wide, ±5–12° rotation, `0 1px 3px #0003` shadow
  - washi: 90deg stripes alternating ee/55 alpha
  - solid: cc alpha
  - dotted: radial dots over base
  - striped: 135deg diagonal stripes
- Notebook grid bg: `linear-gradient(${accent}11 1px, transparent 1px)` × both axes, 28px
- Doodle SVGs: 7 types — star, heart, flower, swirl, sparkle (filled), bow, arrow

### Animations
```
floaty   3–7s ease-in-out infinite   translateY ±6px
wobble   4s ease infinite            rotate -8↔8°
twinkle  2–2.5s ease infinite        opacity .4↔1, scale .9↔1.15
spin     5s linear infinite          rotate 360°
pawFade  1.4s ease-out forwards      opacity 0→1→0, scale .5→1.1→.85
```

## Assets
- **Avatar**: round placeholder with "pb" initials. Replace with a real photo (~256px square recommended). The current placeholder uses a radial gradient and is generated in code.
- **Photos**: 3 placeholders in the photo booth + photos referenced elsewhere — generated as striped gradient SVG-ish backgrounds with labels. Replace with real images.
- **Manga book cover**: synthetic gradient with kanji "フリーレン" — replace with a real cover image.
- **Icons**: small inline SVGs for github, instagram, star, heart, play, paw — see `Icon` object in `source/shared.jsx`.
- **Fonts**: load via Google Fonts — JetBrains Mono, Fredoka, DynaPuff, Caveat, Shrikhand, Pacifico, Reenie Beanie.
- **Cursor mascot**: drawn inline as SVG (head shape + ears + face), no external asset.

## Content (current copy — replace with your own)
- **Profile**: name "pawbies", handle "@pawbies", tagline "silly femboy gymbro ^^", bio "21 · building tiny software and lifting heavy things. probably reading shoujo right now.", pronouns "he/they", location "somewhere cozy · utc+1"
- **Posts, projects, gym lifts, playlist, guestbook, stack** — all in `source/shared.jsx` as plain JS arrays. Move these to markdown / JSON / your CMS of choice.

## Files in this bundle
- `source/Pawbies Home.html` — entrypoint (loads React, Babel, fonts, mounts app)
- `source/zine-home.jsx` — the entire homepage component including tweaks panel wiring, cursor mascot, doodle generator, and all section JSX
- `source/shared.jsx` — data (PROFILE, POSTS, PROJECTS, GYM, STACK, PLAYLIST, GUESTBOOK, GALLERY_COLORS) and small helpers (`Avatar`, `PhotoPlaceholder`, `Icon`)

## Suggested implementation path
1. Pick a stack (Astro is recommended for personal sites — content collections + island components for the cursor mascot).
2. Load fonts the right way (subsetted + `font-display: swap`).
3. Move data out of code: `content/posts/*.md`, `data/projects.json`, `data/gym.json`, etc.
4. Build the layout with CSS Grid (matches the prototype's structure 1:1).
5. Port the cursor-mascot logic to a small client-only component (it's pointer-events disabled and mounted at body root).
6. Drop the tweaks panel for production unless you actually want a visitor-facing theme switcher — in which case persist to localStorage instead of postMessage.
7. Replace placeholder visuals (avatar, photos, manga cover).
8. Add Open Graph + Twitter cards using a screenshot of the hero card.
9. Lighthouse pass — the floaty-doodle layer + spinning vinyl are GPU-cheap but consider `prefers-reduced-motion` to disable them.

## Accessibility notes
- Cursor mascot: hide entirely on touch devices (`pointer: coarse`) and respect `prefers-reduced-motion`.
- Floaty doodles + animations: gate behind `prefers-reduced-motion`.
- Card rotation makes everything tilt — fine for visual interest, but ensure tab order is logical and focus rings are visible against pastel backgrounds.
- Text contrast: the pastel tag pills on paper are borderline. Run a contrast check after any color customization.

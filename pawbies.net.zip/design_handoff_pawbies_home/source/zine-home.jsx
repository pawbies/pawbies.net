// Pawbies — Kawaii zine homepage (full-bleed).
// Builds on the v4 zine variant: stickers, washi tape, doodles, scrapbook collage.
// Adds: paw-trail cursor mascot, animated stickers, accent / paper / doodle / font tweaks.

const { PROFILE, POSTS, PROJECTS, GYM, STACK, PLAYLIST, GUESTBOOK, GALLERY_COLORS, Icon, Avatar, PhotoPlaceholder } = window;
const { TweaksPanel, TweakSection, TweakSlider, TweakRadio, TweakColor, TweakSelect, useTweaks } = window;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "#ff2fb3",
  "paper": "#fff3f9",
  "doodleDensity": 12,
  "cardRotation": 1.5,
  "displayFont": "Shrikhand",
  "scriptFont": "Caveat",
  "showMascot": true,
  "tapeStyle": "washi"
}/*EDITMODE-END*/;

// ── tiny doodle vocabulary ─────────────────────────────────────────────
function Doodle({ type = "star", size = 22, color = "#ff2fb3", style }) {
  const s = { width: size, height: size, ...style };
  switch (type) {
    case "star":   return <svg viewBox="0 0 24 24" style={s}><path d="M12 3 L14 10 L21 11 L15.5 15.5 L17.5 22 L12 18 L6.5 22 L8.5 15.5 L3 11 L10 10 Z" fill="none" stroke={color} strokeWidth="1.5" strokeLinejoin="round"/></svg>;
    case "heart":  return <svg viewBox="0 0 24 24" style={s}><path d="M12 21 C 4 15, 2 10, 6 6 C 9 4, 11 6, 12 8 C 13 6, 15 4, 18 6 C 22 10, 20 15, 12 21 Z" fill="none" stroke={color} strokeWidth="1.5"/></svg>;
    case "flower": return <svg viewBox="0 0 24 24" style={s}><circle cx="12" cy="6" r="3.5" fill="none" stroke={color} strokeWidth="1.5"/><circle cx="6" cy="12" r="3.5" fill="none" stroke={color} strokeWidth="1.5"/><circle cx="18" cy="12" r="3.5" fill="none" stroke={color} strokeWidth="1.5"/><circle cx="12" cy="18" r="3.5" fill="none" stroke={color} strokeWidth="1.5"/><circle cx="12" cy="12" r="2.5" fill={color}/></svg>;
    case "swirl":  return <svg viewBox="0 0 24 24" style={s}><path d="M3 12 Q 8 4, 12 12 T 21 12" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round"/></svg>;
    case "sparkle":return <svg viewBox="0 0 24 24" style={s}><path d="M12 2 L13 10 L22 12 L13 14 L12 22 L11 14 L2 12 L11 10 Z" fill={color}/></svg>;
    case "bow":    return <svg viewBox="0 0 24 24" style={s}><path d="M12 12 L4 7 L4 17 Z M12 12 L20 7 L20 17 Z" fill={color}/><circle cx="12" cy="12" r="2" fill={color}/></svg>;
    case "arrow":  return <svg viewBox="0 0 24 24" style={s}><path d="M3 12 Q 8 6, 14 12 Q 18 16, 21 11 M21 11 L17 11 M21 11 L21 15" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round"/></svg>;
    default: return null;
  }
}

// ── tape ───────────────────────────────────────────────────────────────
function Tape({ color = "#ff2fb3", w = 60, rotate = -8, style, kind = "washi" }) {
  const bgs = {
    washi:  `repeating-linear-gradient(90deg, ${color}aa 0 4px, ${color}55 4px 8px)`,
    solid:  `${color}cc`,
    dotted: `radial-gradient(circle, ${color}ee 1.5px, transparent 1.6px) 0 0/8px 8px, ${color}66`,
    striped:`repeating-linear-gradient(135deg, ${color}cc 0 5px, transparent 5px 10px), ${color}33`,
  };
  return <div style={{
    position:"absolute", width: w, height: 18,
    background: bgs[kind] || bgs.washi,
    transform: `rotate(${rotate}deg)`,
    boxShadow: "0 1px 3px #0003",
    ...style,
  }}/>;
}

// ── card ───────────────────────────────────────────────────────────────
function Card({ rotate = 0, bg, paper, children, style, sticker }) {
  return (
    <div style={{
      background: bg || paper,
      padding: 16,
      transform: `rotate(${rotate}deg)`,
      boxShadow: "0 6px 20px #0006, 0 1px 0 #00000022",
      position:"relative",
      borderRadius: 2,
      ...style,
    }}>
      {sticker}
      {children}
    </div>
  );
}

// ── cursor mascot: paw-trail kitty ─────────────────────────────────────
function CursorMascot({ accent, enabled }) {
  const [paws, setPaws] = React.useState([]);
  const [pos, setPos] = React.useState({ x: -100, y: -100 });
  const lastDrop = React.useRef({ x: -1000, y: -1000, t: 0 });
  const idRef = React.useRef(0);

  React.useEffect(() => {
    if (!enabled) return;
    const onMove = (e) => {
      setPos({ x: e.clientX, y: e.clientY });
      const now = performance.now();
      const dx = e.clientX - lastDrop.current.x;
      const dy = e.clientY - lastDrop.current.y;
      const d = Math.hypot(dx, dy);
      if (d > 60 && now - lastDrop.current.t > 50) {
        const id = idRef.current++;
        const angle = Math.atan2(dy, dx) * 180 / Math.PI;
        const side = idRef.current % 2 ? 12 : -12; // alternating paw L/R
        const px = e.clientX + Math.cos((angle + 90) * Math.PI/180) * side;
        const py = e.clientY + Math.sin((angle + 90) * Math.PI/180) * side;
        setPaws(p => [...p.slice(-12), { id, x: px, y: py, angle }]);
        lastDrop.current = { x: e.clientX, y: e.clientY, t: now };
        setTimeout(() => setPaws(p => p.filter(pw => pw.id !== id)), 1400);
      }
    };
    window.addEventListener("mousemove", onMove);
    return () => window.removeEventListener("mousemove", onMove);
  }, [enabled]);

  if (!enabled) return null;
  return (
    <div style={{position:"fixed", inset: 0, pointerEvents:"none", zIndex: 9999}}>
      {paws.map(p => (
        <svg key={p.id} viewBox="0 0 24 24"
          style={{
            position:"absolute", left: p.x - 9, top: p.y - 9, width: 18, height: 18,
            transform: `rotate(${p.angle + 90}deg)`,
            animation: "pawFade 1.4s ease-out forwards",
          }}>
          <circle cx="6"  cy="9" r="2" fill={accent}/>
          <circle cx="10" cy="5" r="2" fill={accent}/>
          <circle cx="14" cy="5" r="2" fill={accent}/>
          <circle cx="18" cy="9" r="2" fill={accent}/>
          <path d="M12 10c-3 0-5.5 2.5-5.5 5.5 0 2 1.5 3.5 3.5 3.5 1 0 1.5-.5 2-.5s1 .5 2 .5c2 0 3.5-1.5 3.5-3.5C17.5 12.5 15 10 12 10z" fill={accent}/>
        </svg>
      ))}
      {/* lil kitty next to cursor */}
      <div style={{
        position:"absolute", left: pos.x + 14, top: pos.y + 6, width: 36, height: 30,
        transition: "transform .08s ease-out",
      }}>
        <svg viewBox="0 0 60 50" width="36" height="30" style={{filter:`drop-shadow(0 2px 4px #0008)`}}>
          {/* ears */}
          <path d="M10 18 L14 4 L22 14 Z" fill={accent}/>
          <path d="M50 18 L46 4 L38 14 Z" fill={accent}/>
          <path d="M14 14 L16 8 L20 13 Z" fill="#fff3f9"/>
          <path d="M46 14 L44 8 L40 13 Z" fill="#fff3f9"/>
          {/* head */}
          <ellipse cx="30" cy="24" rx="18" ry="14" fill={accent}/>
          {/* face */}
          <circle cx="23" cy="22" r="2" fill="#1a0822"/>
          <circle cx="37" cy="22" r="2" fill="#1a0822"/>
          <circle cx="23.5" cy="21.5" r="0.6" fill="#fff"/>
          <circle cx="37.5" cy="21.5" r="0.6" fill="#fff"/>
          {/* blush */}
          <ellipse cx="20" cy="27" rx="2.5" ry="1.5" fill="#ff6ec7" opacity=".65"/>
          <ellipse cx="40" cy="27" rx="2.5" ry="1.5" fill="#ff6ec7" opacity=".65"/>
          {/* mouth */}
          <path d="M28 27 Q 30 29 32 27" fill="none" stroke="#1a0822" strokeWidth="1.2" strokeLinecap="round"/>
          {/* whiskers */}
          <path d="M14 24 L20 25 M14 27 L20 26" stroke="#fff3f9" strokeWidth="0.8"/>
          <path d="M46 24 L40 25 M46 27 L40 26" stroke="#fff3f9" strokeWidth="0.8"/>
        </svg>
      </div>
      <style>{`
        @keyframes pawFade {
          0%   { opacity: 0; transform: scale(.5) rotate(var(--r)); }
          15%  { opacity: 1; transform: scale(1.1); }
          100% { opacity: 0; transform: scale(0.85); }
        }
      `}</style>
    </div>
  );
}

// ── main ───────────────────────────────────────────────────────────────
function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  const ink = "#2a1535";
  const hot = t.accent;
  const pink = "#ff94d4";
  const lilac = "#d9a7ff";
  const amber = "#ffce6b";
  const mint = "#7affd3";
  const paper = t.paper;
  const display = `'${t.displayFont}', serif`;
  const script = `'${t.scriptFont}', cursive`;

  // doodle field — density-driven
  const doodles = React.useMemo(() => {
    const rng = (seed) => { let s = seed; return () => (s = (s*9301+49297)%233280)/233280; };
    const r = rng(7);
    const types = ["star","heart","flower","swirl","sparkle","bow","arrow"];
    const colors = [hot, pink, lilac, amber, mint];
    return Array.from({length: t.doodleDensity}, (_, i) => ({
      type: types[Math.floor(r()*types.length)],
      color: colors[Math.floor(r()*colors.length)],
      size: 18 + Math.floor(r()*30),
      top: r()*100,
      left: r()*100,
      rot: (r()*60 - 30),
      opacity: 0.25 + r()*0.4,
      dur: 3 + r()*4,
      delay: r()*2,
    }));
  }, [t.doodleDensity, hot]);

  return (
    <div style={{
      minHeight:"100vh", position:"relative",
      background: `
        radial-gradient(ellipse at 25% 15%, #4e1e5a 0%, transparent 55%),
        radial-gradient(ellipse at 75% 85%, #3a2a48 0%, transparent 55%),
        #1f1428
      `,
      color: ink,
      fontFamily: "'Fredoka',sans-serif",
    }}>
      {/* notebook grid */}
      <div style={{position:"fixed", inset:0,
        backgroundImage: `linear-gradient(${hot}11 1px, transparent 1px), linear-gradient(90deg, ${hot}11 1px, transparent 1px)`,
        backgroundSize:"28px 28px", pointerEvents:"none",
      }}/>

      {/* ambient doodles */}
      <div style={{position:"fixed", inset:0, pointerEvents:"none"}}>
        {doodles.map((d,i)=>(
          <Doodle key={i} type={d.type} size={d.size} color={d.color}
            style={{
              position:"absolute", top:`${d.top}%`, left:`${d.left}%`,
              opacity: d.opacity,
              transform:`rotate(${d.rot}deg)`,
              animation: `floaty ${d.dur}s ${d.delay}s ease-in-out infinite`,
            }}/>
        ))}
      </div>

      {/* nav bar */}
      <div style={{
        position:"sticky", top: 0, zIndex: 50,
        padding: "10px 32px",
        background:"#1f1428cc", backdropFilter:"blur(12px)",
        borderBottom:`1px dashed ${hot}55`,
        display:"flex", alignItems:"center", gap: 18,
        color:"#fff3f9",
      }}>
        <span style={{fontFamily: display, fontSize: 22, color: hot, lineHeight: 1}}>pawbies<span style={{color: lilac}}>.net</span></span>
        <span style={{flex:1}}/>
        {["about","blog","projects","gym","photos","guests","links"].map((n,i)=>(
          <a key={i} href={`#${n}`} style={{color:"#fff3f9", textDecoration:"none", fontSize: 13, fontFamily: script, fontWeight: 600, padding:"4px 10px", borderRadius: 99, transition:"background .15s"}}
            onMouseEnter={e=>e.currentTarget.style.background = `${hot}33`}
            onMouseLeave={e=>e.currentTarget.style.background = "transparent"}>
            {n}
          </a>
        ))}
      </div>

      <div style={{maxWidth: 1180, margin:"0 auto", padding: "32px 40px 60px", position:"relative"}}>
        {/* HERO */}
        <div id="about" style={{position:"relative", marginBottom: 40}}>
          <Tape kind={t.tapeStyle} color={hot} w={90} rotate={-12} style={{top: -6, left: 60}}/>
          <Tape kind={t.tapeStyle} color={mint} w={70} rotate={10} style={{top: -8, right: 100}}/>
          <Card paper={paper} rotate={-1} style={{padding:"26px 32px", display:"flex", gap: 24, alignItems:"center"}}>
            <div style={{position:"relative"}}>
              <Avatar size={120} bg={pink} fg={paper} ring={hot} initials="pb"
                style={{boxShadow:`0 0 0 4px ${paper}, 0 0 0 6px ${hot}, 0 8px 20px #0008`}}/>
              <Doodle type="sparkle" size={28} color={amber} style={{position:"absolute", top: -10, right: -12, animation:"twinkle 2s infinite"}}/>
              <Doodle type="heart" size={20} color={hot} style={{position:"absolute", bottom: -4, left: -10}}/>
              <Doodle type="bow" size={28} color={hot} style={{position:"absolute", top: -6, left: 30}}/>
            </div>
            <div style={{flex: 1}}>
              <div style={{fontFamily: script, fontSize: 22, color: hot, lineHeight: 1, marginBottom: 4}}>hi hi !! welcome to</div>
              <div style={{fontFamily: display, fontSize: 80, color: hot, lineHeight: 0.9, letterSpacing: -2}}>
                pawbies<span style={{fontFamily: script, fontSize: 50, color: lilac}}>.net</span>
              </div>
              <div style={{fontFamily: script, fontSize: 26, color: ink, marginTop: 6, lineHeight: 1.1}}>
                ✿ {PROFILE.tagline} ✿
              </div>
              <div style={{fontSize: 14, color: "#2a1535cc", marginTop: 10, maxWidth: 520, lineHeight: 1.5}}>
                {PROFILE.bio}
              </div>
              <div style={{display:"flex", gap: 6, marginTop: 12, flexWrap:"wrap"}}>
                {[PROFILE.pronouns, PROFILE.location, "INFP", "trans rights", "vim btw"].map((tag,i)=>(
                  <span key={i} style={{
                    background:`${pink}66`, padding:"3px 10px", borderRadius: 99,
                    fontSize: 12, fontFamily: script, color: ink, fontWeight: 600,
                    border: `1.5px dashed ${hot}88`,
                  }}>{tag}</span>
                ))}
              </div>
            </div>
          </Card>
        </div>

        {/* COLLAGE GRID */}
        <div style={{display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap: 32, alignItems:"start"}}>
          {/* COL 1 */}
          <div style={{display:"flex", flexDirection:"column", gap: 30}}>
            <div style={{position:"relative"}} id="links">
              <Tape kind={t.tapeStyle} color={amber} w={70} rotate={-8} style={{top: -8, left: 22}}/>
              <Card paper={paper} rotate={-t.cardRotation*1.3} sticker={<Doodle type="flower" size={28} color={hot} style={{position:"absolute", top: -12, right: -8, animation:"wobble 4s infinite"}}/>}>
                <div style={{fontFamily: display, fontSize: 24, color: hot, marginBottom: 8}}>say hi ♡</div>
                <div style={{display:"flex", flexDirection:"column", gap: 8}}>
                  <a href="#" style={{color: ink, textDecoration:"none", display:"flex", gap: 10, alignItems:"center", padding: 6, borderRadius: 6, background:`${hot}11`}}>
                    <span style={{background: hot, color: paper, padding: 6, borderRadius: 6, display:"flex"}}><Icon.gh s={16}/></span>
                    <div>
                      <div style={{fontWeight: 600, fontSize: 13}}>github</div>
                      <div style={{fontSize: 11, color:"#2a1535aa", fontFamily:"'JetBrains Mono',monospace"}}>@{PROFILE.github}</div>
                    </div>
                  </a>
                  <a href="#" style={{color: ink, textDecoration:"none", display:"flex", gap: 10, alignItems:"center", padding: 6, borderRadius: 6, background:`${lilac}22`}}>
                    <span style={{background: lilac, color:"#1a0822", padding: 6, borderRadius: 6, display:"flex"}}><Icon.ig s={16}/></span>
                    <div>
                      <div style={{fontWeight: 600, fontSize: 13}}>instagram</div>
                      <div style={{fontSize: 11, color:"#2a1535aa", fontFamily:"'JetBrains Mono',monospace"}}>@{PROFILE.instagram}</div>
                    </div>
                  </a>
                  <a href="#" style={{color: ink, textDecoration:"none", display:"flex", gap: 10, alignItems:"center", padding: 6, borderRadius: 6, background:`${mint}22`}}>
                    <span style={{background: mint, color:"#1a0822", padding: 6, borderRadius: 6, display:"flex", fontSize: 14, fontWeight: 700}}>✉</span>
                    <div>
                      <div style={{fontWeight: 600, fontSize: 13}}>email</div>
                      <div style={{fontSize: 11, color:"#2a1535aa", fontFamily:"'JetBrains Mono',monospace"}}>hi@pawbies.net</div>
                    </div>
                  </a>
                </div>
              </Card>
            </div>

            <div style={{position:"relative"}} id="photos">
              <Tape kind={t.tapeStyle} color={hot} w={50} rotate={-10} style={{top:-6, left:"50%", marginLeft:-25}}/>
              <Card paper="#1a0822" rotate={t.cardRotation*0.8} style={{padding: 8}}>
                {[0,1,2].map(i=>(
                  <div key={i} style={{padding: 5, background: paper, marginBottom: 5, transform:`rotate(${(i%2?-0.5:0.5)}deg)`}}>
                    <PhotoPlaceholder h={84} label={["spring '26","gym pr","cafe"][i]} colors={GALLERY_COLORS[i]}/>
                  </div>
                ))}
                <div style={{textAlign:"center", color: pink, fontFamily: script, fontSize: 16, padding: 4}}>
                  photo booth ♡
                </div>
              </Card>
            </div>

            <div style={{position:"relative"}}>
              <Tape kind={t.tapeStyle} color={mint} w={60} rotate={-5} style={{top:-6, right: 30}}/>
              <Card paper={paper} rotate={-t.cardRotation*0.6} style={{border:`2.5px dashed ${hot}66`}}>
                <div style={{fontFamily: display, fontSize: 20, color: hot, marginBottom: 8}}>my stack ★</div>
                <div style={{fontSize: 12, lineHeight: 1.7}}>
                  {STACK.map((s,i)=>(
                    <div key={i} style={{display:"flex", gap: 8, alignItems:"baseline"}}>
                      <span style={{fontFamily: script, fontSize: 16, color: hot, minWidth: 70}}>{s.cat}:</span>
                      <span style={{flex:1}}>{s.items.join(", ")}</span>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          </div>

          {/* COL 2 */}
          <div style={{display:"flex", flexDirection:"column", gap: 30, marginTop: 18}}>
            <div style={{position:"relative"}} id="blog">
              <Tape kind={t.tapeStyle} color={pink} w={90} rotate={6} style={{top:-8, right: 30}}/>
              <Card paper={paper} rotate={t.cardRotation}>
                <div style={{fontFamily: display, fontSize: 26, color: hot, marginBottom: 10}}>blog ✎</div>
                {POSTS.map((p,i)=>(
                  <div key={i} style={{padding: "8px 0", borderBottom: i<POSTS.length-1?`1.5px dashed ${hot}55`:"none"}}>
                    <div style={{fontSize: 13.5, fontWeight: 600, color: ink, lineHeight: 1.3}}>{p.title}</div>
                    <div style={{display:"flex", justifyContent:"space-between", marginTop: 3, alignItems:"baseline"}}>
                      <span style={{fontFamily: script, fontSize: 15, color: hot}}>#{p.tag}</span>
                      <span style={{fontSize: 10.5, color:"#2a1535aa", fontFamily:"'JetBrains Mono',monospace"}}>{p.date.slice(0,10)} · {p.read}</span>
                    </div>
                  </div>
                ))}
                <a href="#" style={{display:"block", textAlign:"right", marginTop: 6, color: hot, fontFamily: script, fontSize: 16, textDecoration:"none"}}>more posts →</a>
              </Card>
            </div>

            <div style={{position:"relative"}}>
              <Tape kind={t.tapeStyle} color={amber} w={50} rotate={12} style={{top:-6, left: 40}}/>
              <Card paper={paper} rotate={-t.cardRotation*1.2}>
                <div style={{display:"flex", gap: 12, alignItems:"flex-start"}}>
                  <div style={{
                    width: 64, height: 64, borderRadius:"50%",
                    background:`conic-gradient(${hot}, ${lilac}, ${mint}, ${amber}, ${hot})`,
                    border: "2.5px solid #1a0822",
                    display:"flex", alignItems:"center", justifyContent:"center",
                    animation:"spin 5s linear infinite",
                    flex:"0 0 auto",
                  }}>
                    <div style={{width: 18, height: 18, borderRadius:"50%", background:"#1a0822", border:`2.5px solid ${paper}`}}/>
                  </div>
                  <div style={{flex:1, minWidth:0}}>
                    <div style={{fontFamily: script, fontSize: 18, color: hot, lineHeight: 1}}>now spinning ♪</div>
                    <div style={{fontSize: 14, fontWeight: 700, marginTop: 2}}>{PLAYLIST[0].title}</div>
                    <div style={{fontSize: 12, color:"#2a1535aa"}}>{PLAYLIST[0].artist}</div>
                  </div>
                </div>
                <div style={{marginTop: 10, fontSize: 11.5, fontFamily:"'JetBrains Mono',monospace", color:"#2a1535bb", lineHeight: 1.6}}>
                  {PLAYLIST.slice(1,4).map((tt,i)=>(
                    <div key={i} style={{display:"flex", gap: 6}}>
                      <span style={{color: hot}}>♪</span>
                      <span style={{flex:1}}>{tt.artist} — {tt.title}</span>
                      <span style={{color:"#2a1535aa", fontStyle:"italic"}}>{tt.note}</span>
                    </div>
                  ))}
                </div>
              </Card>
            </div>

            <div style={{position:"relative"}} id="gym">
              <Tape kind={t.tapeStyle} color={hot} w={70} rotate={-10} style={{top:-8, left: 30}}/>
              <Card paper={paper} rotate={t.cardRotation*0.7} sticker={<Doodle type="star" size={26} color={amber} style={{position:"absolute", top:-14, right: 20, animation:"twinkle 2.5s infinite"}}/>}>
                <div style={{fontFamily: display, fontSize: 22, color: hot, marginBottom: 8}}>gym log ⚡</div>
                <div style={{display:"flex", justifyContent:"space-between", marginBottom: 10, alignItems:"baseline"}}>
                  <span style={{fontFamily: script, fontSize: 30, color: hot, lineHeight: 1}}>{GYM.streak} days!!</span>
                  <span style={{fontSize: 11, color:"#2a1535aa"}}>{GYM.split}</span>
                </div>
                {GYM.lifts.map((l,i)=>(
                  <div key={i} style={{display:"flex", justifyContent:"space-between", fontSize: 12, padding: "4px 0", borderBottom: i<GYM.lifts.length-1?`1px dotted ${hot}55`:"none"}}>
                    <span style={{fontFamily: script, fontSize: 17, color: ink}}>{l.name}</span>
                    <span style={{fontWeight: 700, color: hot, fontFamily:"'JetBrains Mono',monospace"}}>{l.weight}</span>
                  </div>
                ))}
              </Card>
            </div>
          </div>

          {/* COL 3 */}
          <div style={{display:"flex", flexDirection:"column", gap: 30}}>
            <div style={{position:"relative"}} id="guests">
              <Tape kind={t.tapeStyle} color={lilac} w={70} rotate={6} style={{top:-8, left: 30}}/>
              <Card paper={paper} rotate={t.cardRotation*1.3} sticker={<Doodle type="heart" size={22} color={hot} style={{position:"absolute", top:-12, right: 16}}/>}>
                <div style={{fontFamily: display, fontSize: 24, color: hot, marginBottom: 8}}>guestbook</div>
                {GUESTBOOK.map((g,i)=>(
                  <div key={i} style={{
                    padding: 8, marginBottom: 6,
                    background: i%2 ? `${pink}33` : `${mint}33`,
                    fontFamily: script, fontSize: 15,
                    transform: `rotate(${(i%2?-0.6:0.6)}deg)`,
                    borderRadius: 4,
                  }}>
                    <div style={{fontWeight: 700, color: hot, fontSize: 14}}>{g.who} <span style={{color:"#2a1535aa", fontSize: 11, fontFamily:"'JetBrains Mono',monospace"}}>· {g.when}</span></div>
                    <div style={{lineHeight: 1.2, marginTop: 2}}>"{g.msg}"</div>
                  </div>
                ))}
                <button style={{
                  marginTop: 6, width:"100%",
                  background: `linear-gradient(180deg, ${hot}, ${pink})`,
                  border:"2px solid #1a0822", color:"#1a0822",
                  fontFamily: script, fontSize: 18, fontWeight: 700,
                  padding:"6px 12px", cursor:"pointer",
                  boxShadow:`2px 2px 0 #1a0822`,
                  borderRadius: 4,
                }}>✎ sign it!!</button>
              </Card>
            </div>

            <div style={{position:"relative", marginTop: 20}} id="projects">
              <Tape kind={t.tapeStyle} color={mint} w={60} rotate={-7} style={{top:-8, right: 40}}/>
              <Card paper={paper} rotate={-t.cardRotation*1.1}>
                <div style={{fontFamily: display, fontSize: 22, color: hot, marginBottom: 8}}>projects ✿</div>
                {PROJECTS.map((pr,i)=>(
                  <div key={i} style={{padding: "8px 0", borderBottom: i<PROJECTS.length-1?`1.5px dashed ${hot}44`:"none"}}>
                    <div style={{display:"flex", justifyContent:"space-between", alignItems:"center"}}>
                      <span style={{fontFamily:"'JetBrains Mono',monospace", color: hot, fontSize: 13, fontWeight: 700}}>./{pr.name}</span>
                      <span style={{display:"inline-flex", alignItems:"center", gap: 3, fontSize: 11, color:"#2a1535aa"}}><Icon.star s={11}/>{pr.stars}</span>
                    </div>
                    <div style={{fontSize: 12, color: ink, lineHeight: 1.4, marginTop: 2}}>{pr.desc}</div>
                    <div style={{fontSize: 10.5, color: lilac, marginTop: 3, fontFamily:"'JetBrains Mono',monospace"}}>● {pr.lang}</div>
                  </div>
                ))}
              </Card>
            </div>

            {/* currently reading mini-card */}
            <div style={{position:"relative"}}>
              <Tape kind={t.tapeStyle} color={hot} w={50} rotate={-8} style={{top:-6, left: 30}}/>
              <Card paper={paper} rotate={t.cardRotation}>
                <div style={{fontFamily: display, fontSize: 18, color: hot, marginBottom: 6}}>reading rn 📖</div>
                <div style={{display:"flex", gap: 10, alignItems:"center"}}>
                  <div style={{width: 48, height: 64, background: `linear-gradient(160deg, ${hot}, ${lilac})`, borderRadius: 2, boxShadow:"0 2px 6px #0006", display:"flex", alignItems:"center", justifyContent:"center", color: paper, fontFamily: display, fontSize: 10, textAlign:"center", padding: 4, lineHeight: 1.1}}>
                    フリーレン
                  </div>
                  <div style={{flex:1}}>
                    <div style={{fontSize: 13, fontWeight: 700}}>Frieren vol. 12</div>
                    <div style={{fontSize: 11, color:"#2a1535aa"}}>Yamada Kanehito</div>
                    <div style={{fontFamily: script, fontSize: 14, color: hot, marginTop: 4}}>★★★★☆ so peaceful</div>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </div>

        {/* footer */}
        <div style={{textAlign:"center", marginTop: 50, fontFamily: script, color: pink, fontSize: 22, lineHeight: 1.4}}>
          made with ♡ &amp; protein by pb · 2026<br/>
          <span style={{fontSize: 13, color:"#a888b8", fontFamily:"'JetBrains Mono',monospace"}}>thanks for stopping by ✿</span>
        </div>
      </div>

      {/* Cursor mascot */}
      <CursorMascot accent={hot} enabled={t.showMascot}/>

      {/* Tweaks panel */}
      <TweaksPanel title="tweaks ✿">
        <TweakSection label="Color"/>
        <TweakColor label="Accent" value={t.accent} onChange={(v)=>setTweak('accent', v)}/>
        <TweakSelect label="Paper" value={t.paper}
          options={[
            {label:"cream", value:"#fff3f9"},
            {label:"vanilla", value:"#fff7e8"},
            {label:"mint", value:"#e8fff5"},
            {label:"sky", value:"#eaf3ff"},
            {label:"lilac", value:"#f4eaff"},
          ]}
          onChange={(v)=>setTweak('paper', v)}/>

        <TweakSection label="Decor"/>
        <TweakSlider label="Doodle density" value={t.doodleDensity} min={0} max={30} unit="" onChange={(v)=>setTweak('doodleDensity', v)}/>
        <TweakSlider label="Card tilt" value={t.cardRotation} min={0} max={4} step={0.25} unit="°" onChange={(v)=>setTweak('cardRotation', v)}/>
        <TweakRadio label="Tape" value={t.tapeStyle}
          options={["washi","solid","dotted","striped"]}
          onChange={(v)=>setTweak('tapeStyle', v)}/>

        <TweakSection label="Type"/>
        <TweakRadio label="Display" value={t.displayFont}
          options={["Shrikhand","DynaPuff","Pacifico"]}
          onChange={(v)=>setTweak('displayFont', v)}/>
        <TweakRadio label="Script" value={t.scriptFont}
          options={["Caveat","Reenie Beanie","Fredoka"]}
          onChange={(v)=>setTweak('scriptFont', v)}/>

        <TweakSection label="Mascot"/>
        <TweakRadio label="Kitty cursor" value={t.showMascot ? "on" : "off"}
          options={["on","off"]}
          onChange={(v)=>setTweak('showMascot', v === "on")}/>
      </TweaksPanel>

      <style>{`
        @keyframes floaty { 0%,100%{transform: translateY(0) rotate(var(--r,0deg))} 50%{transform: translateY(-6px) rotate(var(--r,0deg))} }
        @keyframes wobble { 0%,100%{transform:rotate(-8deg)} 50%{transform:rotate(8deg)} }
        @keyframes twinkle{ 0%,100%{opacity:.4;transform:scale(.9)} 50%{opacity:1;transform:scale(1.15)} }
        @keyframes spin{ from{transform:rotate(0)} to{transform:rotate(360deg)} }
      `}</style>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);

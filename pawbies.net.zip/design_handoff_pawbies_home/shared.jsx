// Shared data + little utility components used across variants.
// Name/handle: defaults; user confirmed 'pawbies' as the site name.

const PROFILE = {
  name: "pawbies",
  handle: "@pawbies",
  tagline: "silly femboy gymbro ^^",
  bio: "21 · building tiny software and lifting heavy things. probably reading shoujo right now.",
  location: "somewhere cozy · utc+1",
  pronouns: "he/they",
  github: "pawbies",
  instagram: "pawbies",
};

const POSTS = [
  { date: "2026-04-18", title: "rewriting my blog in htmx (again)", tag: "dev",    read: "4 min" },
  { date: "2026-04-09", title: "push day PR: 2.2x bw bench",         tag: "gym",    read: "2 min" },
  { date: "2026-03-28", title: "on being cute AND legible",          tag: "essay",  read: "7 min" },
  { date: "2026-03-14", title: "vim keybinds i can't live without",  tag: "dev",    read: "5 min" },
  { date: "2026-02-22: ", title: "frieren s2 notes (no spoilers)",     tag: "anime",  read: "3 min" },
];

const PROJECTS = [
  { name: "kittycal",   desc: "calorie tracker that's mean to u in a loving way", stars: 412,  lang: "typescript" },
  { name: "dotfiles",   desc: "my neovim + hyprland + ricing setup",              stars: 1208, lang: "lua" },
  { name: "femboy.css", desc: "a css reset but pink",                             stars: 89,   lang: "css" },
  { name: "gymlog",     desc: "tiny local-first workout tracker",                  stars: 56,   lang: "rust" },
];

const GYM = {
  streak: 47,
  bodyweight: "68 kg",
  lifts: [
    { name: "bench",    weight: "150 kg", unit: "1rm", bar: 0.92 },
    { name: "squat",    weight: "180 kg", unit: "1rm", bar: 0.86 },
    { name: "deadlift", weight: "205 kg", unit: "1rm", bar: 0.95 },
    { name: "ohp",      weight: "75 kg",  unit: "1rm", bar: 0.68 },
  ],
  split: "ppl · 6x/week",
};

const STACK = [
  { cat: "editor",   items: ["neovim",  "helix"] },
  { cat: "shell",    items: ["zsh",  "starship", "zellij"] },
  { cat: "lang",     items: ["rust", "ts", "python"] },
  { cat: "os",       items: ["arch btw",  "hyprland"] },
  { cat: "keyboard", items: ["corne v4", "cherry browns"] },
  { cat: "gym",      items: ["rogue bar", "versa grips"] },
];

const PLAYLIST = [
  { artist: "fromis_9", title: "#menow",          note: "gym warmup" },
  { artist: "yorushika", title: "茜色に染まる",   note: "writing" },
  { artist: "aespa",    title: "Whiplash",        note: "deadlift day" },
  { artist: "Porter Robinson", title: "Cheerleader", note: "walks" },
  { artist: "tricot",   title: "おちゃんせんすぅす", note: "reading" },
];

const GUESTBOOK = [
  { who: "@catjail",     when: "2d",  msg: "ur site broke my eyes in the best way <3" },
  { who: "@linuxdweeb",  when: "5d",  msg: "please open-source femboy.css i need it" },
  { who: "@haruka",      when: "1w",  msg: "frieren post was beautiful ;_; tysm" },
  { who: "@benchpress",  when: "2w",  msg: "how are your wrists so strong" },
];

const GALLERY_COLORS = [
  ["#3a1d4a","#ff6ec7"],
  ["#1f1428","#d9a7ff"],
  ["#4e1e5a","#ff2fb3"],
  ["#2a1535","#ffce6b"],
  ["#5a2a6e","#7affd3"],
  ["#1a0f22","#ff94d4"],
];

// Tiny placeholder-photo component — striped plum with label.
// Use this wherever a real photo would go.
function PhotoPlaceholder({ w = "100%", h = "100%", label = "photo", colors, style, rounded = 0, border }) {
  const [c1, c2] = colors || ["#3a1d4a","#ff6ec7"];
  return (
    <div style={{
      width: w, height: h, borderRadius: rounded, border,
      background: `repeating-linear-gradient(135deg, ${c1} 0 12px, ${c2}22 12px 24px)`,
      display: "flex", alignItems: "center", justifyContent: "center",
      fontFamily: "JetBrains Mono, monospace", fontSize: 10, color: c2,
      letterSpacing: 1, textTransform: "uppercase", position: "relative",
      overflow: "hidden",
      ...style
    }}>
      <span style={{background: "#1a1020cc", padding: "3px 8px", borderRadius: 3, border:`1px dashed ${c2}66`}}>{label}</span>
    </div>
  );
}

// Avatar placeholder — circle with initials, magenta ring.
function Avatar({ size = 64, ring = "var(--magenta)", bg = "#3a1d4a", fg = "#ff94d4", initials = "pb", style }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: "50%",
      background: `radial-gradient(circle at 30% 30%, ${fg}33, ${bg})`,
      border: `2px solid ${ring}`,
      display:"flex", alignItems:"center", justifyContent:"center",
      color: fg, fontFamily: "JetBrains Mono, monospace", fontWeight: 700, fontSize: size*0.34,
      letterSpacing: 1, flex:"0 0 auto",
      boxShadow: `0 0 24px ${ring}44, inset 0 0 12px ${bg}`,
      ...style,
    }}>{initials}</div>
  );
}

// Inline icons — github, instagram, folder, star, etc.
const Icon = {
  gh: (p)=> <svg width={p.s||16} height={p.s||16} viewBox="0 0 16 16" fill="currentColor"><path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0 0 16 8c0-4.42-3.58-8-8-8z"/></svg>,
  ig: (p)=> <svg width={p.s||16} height={p.s||16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/></svg>,
  star: (p)=> <svg width={p.s||12} height={p.s||12} viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3 7h7l-5.5 4.5L18 21l-6-4-6 4 1.5-7.5L2 9h7z"/></svg>,
  heart:(p)=> <svg width={p.s||12} height={p.s||12} viewBox="0 0 24 24" fill="currentColor"><path d="M12 21s-7-4.5-9.5-9A5.5 5.5 0 0 1 12 6a5.5 5.5 0 0 1 9.5 6c-2.5 4.5-9.5 9-9.5 9z"/></svg>,
  play: (p)=> <svg width={p.s||12} height={p.s||12} viewBox="0 0 24 24" fill="currentColor"><path d="M7 5v14l12-7z"/></svg>,
  folder:(p)=> <svg width={p.s||14} height={p.s||14} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>,
  spark: (p)=> <svg width={p.s||14} height={p.s||14} viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l1.5 6.5L20 10l-6.5 1.5L12 18l-1.5-6.5L4 10l6.5-1.5z"/></svg>,
  paw:  (p)=> <svg width={p.s||16} height={p.s||16} viewBox="0 0 24 24" fill="currentColor"><circle cx="5.5" cy="9" r="2"/><circle cx="9" cy="5" r="2"/><circle cx="15" cy="5" r="2"/><circle cx="18.5" cy="9" r="2"/><path d="M12 10c-3 0-5.5 2.5-5.5 5.5 0 2 1.5 3.5 3.5 3.5 1 0 1.5-.5 2-.5s1 .5 2 .5c2 0 3.5-1.5 3.5-3.5C17.5 12.5 15 10 12 10z"/></svg>,
};

Object.assign(window, { PROFILE, POSTS, PROJECTS, GYM, STACK, PLAYLIST, GUESTBOOK, GALLERY_COLORS, PhotoPlaceholder, Avatar, Icon });
